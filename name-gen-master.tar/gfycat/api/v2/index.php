<?php

    header('HTTP/1.1 403 Forbidden', true, 403);

    //echo createName();

    function createName(){


        $animals    = nl2br(file_get_contents("http://assets.gfycat.com/animals"    ));
        $adjectives = nl2br(file_get_contents("http://assets.gfycat.com/adjecticves"));
        $explodedAnimals    = explode("\n", $animals   );
        $explodedAdjectives = explode("\n", $adjectives);
        $randAnimal     = ucfirst($explodedAnimals   [rand(0, count($explodedAnimals   ) - 1)]);
        $randAdjective1 = ucfirst($explodedAdjectives[rand(0, count($explodedAdjectives) - 1)]);
        $randAdjective2 = ucfirst($explodedAdjectives[rand(0, count($explodedAdjectives) - 1)]);
        
        $result = $randAdjective1. $randAdjective2. $randAnimal;

        for ($x=0; $x <3 ; $x++) { 
            $result = str_replace("<br />", "", $result);
        }

        return $result;

    }

?>