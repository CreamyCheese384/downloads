<?php

    echo createName();

    function createName(){

        for ($x=0; $x < 3 ; $x++) { 
            $result = 
            trim(
                str_replace("<br />", "", 
                    ucfirst(explode("\n", 
                        nl2br(
                            file_get_contents("adjectives.txt")
                        )
                    )[
                        rand(0, 
                            count(
                                explode("\n", 
                                    nl2br(
                                        file_get_contents("adjectives.txt")
                                        )
                                    )
                                )
                            -1)
                        ]
                    ).
                    ucfirst(
                        explode("\n", 
                            nl2br(
                                file_get_contents("adjectives.txt")
                                )
                            )[
                                rand(0, 
                                    count(
                                        explode("\n", 
                                            nl2br(
                                                file_get_contents("adjectives.txt")
                                            )
                                        )
                                    )
                                -1)
                            ]
                        ).
                    ucfirst(
                        explode("\n", 
                            nl2br(
                                file_get_contents("animals.txt")
                            )
                        )[
                            rand(0,
                                count(
                                    explode("\n", 
                                        nl2br(
                                            file_get_contents("animals.txt")
                                        )
                                    )
                                )-1
                            )
                        ]
                    )
                )
            );
        }
    

        return $result;
    }
?>